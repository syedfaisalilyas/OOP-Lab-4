﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MANAGEMENT_SYSTEM.bl
{
    class society
    {
        public string society_member_username;
        public string society_member_email;
        public string society_member_contact;
        public string society_description;
        public string society_name;
        public string society_president;
        public List<string> feedback = new List<string>();
        public List<string> eventlist = new List<string>();
        public List<string> requestlist = new List<string>();
        public List<string> donations = new List<string>();
        public List<string> missions = new List<string>();
       
        public society()
        {

        }

        public society(string society_name,string society_description,string society_president)
        {
            this.society_name = society_name;
            this.society_description = society_description;
            this.society_president = society_president;
        }
      /*  public society(string society_member_username, string society_member_email, string society_member_contact)
        {
            this.society_member_username = society_member_username;
            this.society_member_email = society_member_email;
            this.society_member_contact = society_member_contact;
        }*/
        public bool isString(string str)
        {

            for (int i = 0; i < str.Length; i++)
            {
                if ((!char.IsLetter(str[i])) && str[i] != ' ')
                {
                    return false;
                }
            }
            return true;
        }
        public bool isInteger(string str)
        {

            for (int i = 0; i < str.Length; i++)
            {
                if ((!char.IsDigit(str[i])) && str[i] != ' ')
                {
                    return false;
                }
            }
            return true;
        }

        public void addtosociety(List<society> s,society s1)
        {
            s.Add(s1);
        }
    }
}
