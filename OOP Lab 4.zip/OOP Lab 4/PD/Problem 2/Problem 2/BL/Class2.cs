﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_2.BL
{
    class Subject
    {
        public string SubjectType;
        public string SubjectCode;
        public int CreditHours;
        public int SubjectFee;
    }
}
