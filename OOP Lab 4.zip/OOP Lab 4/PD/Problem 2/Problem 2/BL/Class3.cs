﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_2.BL
{
    class DegreeProgram
    {
        public string ProgramTitle;
        public string DegreeDuration;
        public int AvailableSeats;
        public float merit;
        public List<Subject> NewSubjects = new List<Subject>();
        public DegreeProgram(string ProgramTitle, string DegreeDuration, int AvailableSeats, float merit, List<Subject> ListofSub)
        {
            this.ProgramTitle = ProgramTitle;
            this.DegreeDuration = DegreeDuration;
            this.AvailableSeats = AvailableSeats;
            this.merit = merit;
            for (int i = 0; i < ListofSub.Count; i++)
            {
                this.NewSubjects.Add(ListofSub[i]);
            }

        }
        public DegreeProgram(string ProgramTitle, string DegreeDuration, int AvailableSeats, float merit)
        {
            this.ProgramTitle = ProgramTitle;
            this.DegreeDuration = DegreeDuration;
            this.AvailableSeats = AvailableSeats;
            this.merit = merit;
        }
        public void addsubject(Subject s)
        {
            NewSubjects.Add(s);
        }
    }
}
