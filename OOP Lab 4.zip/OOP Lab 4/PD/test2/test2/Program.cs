﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace test2
{
	internal class Program
	{
		static List<ingredients> items = new List<ingredients>();
		static void Main(string[] args)
		{
			ingredients ingredient1 = new ingredients("Strawberries", 1.50);
			items.Add(ingredient1);
			ingredients ingredient2 = new ingredients("Banana", 0.50);
			items.Add(ingredient2);
			ingredients ingredient3 = new ingredients("Mango", 2.50);
			items.Add(ingredient3);
			ingredients ingredient4 = new ingredients("Blueberries", 1.00);
			items.Add(ingredient4);
			ingredients ingredient5 = new ingredients("Raspberries", 1.00);
			items.Add(ingredient5);
			ingredients ingredient6 = new ingredients("Apple", 1.75);
			items.Add(ingredient6);
			ingredients ingredient7 = new ingredients("Pineapple", 3.50);
			items.Add(ingredient7);

			
			List<string> smoothies = GetSmoothieFromInput();
			Smoothie s = new Smoothie(smoothies);
			outputResult(s);
		}

		public static void outputResult(Smoothie s)
		{

			Console.WriteLine(Math.Round(s.GetCost(), 2));
			Console.WriteLine(Math.Round(s.GetPrice(), 2));
			Console.WriteLine(s.GetName());
		}
		public static List<string> GetSmoothieFromInput()
		{
			int n = int.Parse(Console.ReadLine());
			List<string> ingredients = new List<string>();
			for (int i = 0; i < n; ++i)
			{
				string _params = Console.ReadLine();
				ingredients.Add(_params);
			}
			return ingredients;
		}

		public class Smoothie
		{
			public List<string> Ingredients = new List<string>();
			public string Ingredient;
			public ingredients a;

			public Smoothie(string Ingredient)
            {
				this.Ingredient = Ingredient;
            }
			public Smoothie(List<string> Ingredients)
			{
				// Write Code Here
				

			}

			public double GetCost()
			{
				// Write Code Here
				double price = 0.00;
				if(Ingredient == "Banana" )
                {
					price = 1.50;
                }
				else if(Ingredient == "Strawberry")
                {
					price = 0.50;
                }
				else if(Ingredient == "Mango")
                {
					price = 2.50;
                }
				else if(Ingredient == "Blueberry" || Ingredient == "Raspberries")
                {
					price = 1.00;
                }
				else if(Ingredient == "Apple")
                {
					price = 1.75;
                }
				else if(Ingredient == "PineApple")
                {
					price = 3.50;
                }
				return price;

			}
			public double GetPrice(Smoothie s)
			{
				// Write Code Here
				int total;
				total = s.GetCost() + (s.GetCost() * 1.5);
				return total;
			}
			public string GetName()
			{
				// Write Code Here
				return Ingredient;
			

			}
			public bool writenameatend(int num_ingrdient)
            {
				if(num_ingrdient == 1)
                {
					return true;
                }
				return false;
            }

			public void display()
            {

				Smoothie s = new Smoothie();
				if(s.writenameatend())
                {
					Console.WriteLine("Smoothie");
                }
				else
                {
					Console.WriteLine("Fusion");

				}
			}
		}
		public class ingredients
		{
			public string name;
			public double price;

			public ingredients(string name, double price)
			{
				// Write Code Here	
				this.name = name;
				this.price = price;
			}
		}


	}
}