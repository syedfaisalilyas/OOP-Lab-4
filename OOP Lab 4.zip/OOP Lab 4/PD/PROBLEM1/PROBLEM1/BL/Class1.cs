﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROBLEM1.BL
{
    class Angle
    {
       public int degrees;
       public float minutes;
       public char direction;

        public Angle()
        {


        }
        public Angle(int degrees,float minutes,char direction)
        {
            this.degrees = degrees;
            this.minutes = minutes;
            this.direction = direction;
        }
        public void correctformat()
        {
            Console.WriteLine(degrees + "\u00b0" + minutes + "'" + direction);
        }
    }
}
