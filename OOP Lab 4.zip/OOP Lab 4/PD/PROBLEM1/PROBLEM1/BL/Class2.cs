﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROBLEM1.BL
{
    class Ship
    {
        public string number;
        public Angle latitude;
        public Angle longitude;

        public Ship()
        {

        }
        public Ship(string number,Angle latitude,Angle longitude)
        {
            this.number = number;
            this.latitude = latitude;
            this.longitude = longitude;
        }
        public string getserialnumber(int latd,int lond,float latm,float lonm,char latdi,char londi,List<Ship> listofships)
        {

            foreach (Ship i in listofships)
            {
                if (i.latitude.degrees == latd && i.latitude.minutes == latm && i.latitude.direction == latdi && i.longitude.degrees == lond && i.longitude.minutes == lonm && i.longitude.direction == londi)
                {
                    return i.number;
                }
            }
            return null;
}
public void addtolist(List<Ship> l,Ship s)
        {
            l.Add(s);
        }
        public void printposition()
        {
            Console.WriteLine(number);
        }

        public string latitudecorrectformat()
        {
           return  latitude.degrees + "\u00b0" +latitude.minutes + "'" +latitude.direction;
        }  
        public string longitudecorrectformat()
        {
            return longitude.degrees + "\u00b0" +longitude.minutes + "'" +longitude.direction;
        }
    }
}
