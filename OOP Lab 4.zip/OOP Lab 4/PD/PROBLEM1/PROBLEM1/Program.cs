﻿using PROBLEM1.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROBLEM1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Ship> listofships = new List<Ship>();
            int option;
            do
            {
                printmenu();
                Console.WriteLine("Enter Option:");
                option= int.Parse(Console.ReadLine());
                if(option == 1)
                {
                 Ship s = addship();
                 s.addtolist(listofships,s);
                }
                if(option == 2)
                {
                    viewshipposition(listofships);
                }
                if(option == 3)
                {
                    ViewShipSerialNumber(listofships);
                }
                if(option ==4 )
                {
                    changeposition(listofships);
                }
            }
            while (option != 5);
            Console.ReadLine();
        }

        static void printmenu()
        {
            Console.WriteLine("1.Add Ship");
            Console.WriteLine("2. View Ship Position");
            Console.WriteLine("3. View Ship Serial Number");
            Console.WriteLine("4. Change Ship Position");
            Console.WriteLine("5. Exit");
        }

        static void changeposition(List<Ship> listofships)
        {
            Console.WriteLine("Enter Ship's serial number whose position you want to change:");
            string posi = Console.ReadLine();

            foreach(Ship i in listofships)
            {
                if(i.number == posi)
                {
                    Console.WriteLine("Enter Ship Latitude:");
                    Console.WriteLine("Enter Latitude's Degree:");
                    i.latitude.degrees = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Latitude's Minute:");
                    i.latitude.minutes = float.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Latitude's Direction:");
                    i.latitude.direction = char.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Ship Longitude:");
                    Console.WriteLine("Enter Longitude's Degree:");
                    i.longitude.degrees = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Longitude's Minute:");
                    i.longitude.minutes = float.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Longitude's Direction:");
                    i.longitude.direction= char.Parse(Console.ReadLine());
                }

            }
        }

        static void ViewShipSerialNumber(List<Ship> listofships)
        {
            Ship s = new Ship();
            Console.WriteLine("Enter Ship Latitude:");
            Console.WriteLine("Enter Latitude's Degree:");
            int latd = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Latitude's Minute:");
            float latm = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter Latitude's Direction:");
            char latdi = char.Parse(Console.ReadLine());
            Console.WriteLine("Enter Ship Longitude:");
            Console.WriteLine("Enter Longitude's Degree:");
            int lond = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Longitude's Minute:");
            float lonm = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter Longitude's Direction:");
            char londi = char.Parse(Console.ReadLine());
            string st = s.getserialnumber(latd, lond, latm, lonm, latdi, londi,listofships);
            Console.WriteLine("Ship's Serial Number is:" + st);
        }



        static void viewshipposition(List<Ship> listofships)
        {
            Ship s = new Ship();
            Console.WriteLine("Enter Ship Serial Number to find its position:");
            s.number = Console.ReadLine();
            foreach(Ship i in listofships)
            {
                if(i.number == s.number)
                {
                    Console.WriteLine("Ship is at" + i.latitudecorrectformat() + "and" + i.longitudecorrectformat()) ;
                }
            }
        }

        static Ship addship()
        {
            Ship s = new Ship();
            s.latitude = new Angle();
            s.longitude = new Angle();
            Console.WriteLine("Enter Ship Number:");
            s.number = Console.ReadLine();
            Console.WriteLine("Enter Ship Latitude:");
            Console.WriteLine("Enter Latitude's Degree:");
            s.latitude.degrees = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Latitude's Minute:");
            s.latitude.minutes = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter Latitude's Direction:");
            s.latitude.direction = char.Parse(Console.ReadLine());
            Console.WriteLine("Enter Ship Longitude:");
            Console.WriteLine("Enter Longitude's Degree:");
            s.longitude.degrees = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Longitude's Minute:");
            s.longitude.minutes = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter Longitude's Direction:");
            s.longitude.direction = char.Parse(Console.ReadLine());
            Ship s1 = new Ship(s.number, s.latitude, s.longitude);
            return s1;

        }

    }
}
