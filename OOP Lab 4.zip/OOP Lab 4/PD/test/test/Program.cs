﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace IceCreams
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<IceCream> ices = GetIceCreamsFromInput();
            Console.WriteLine(SweetestIceCream(ices));
        }

        public static List<IceCream> GetIceCreamsFromInput()
        {
            List<IceCream> iceCreams = new List<IceCream>();

            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; ++i)
            {
                string[] _params = Console.ReadLine().Split(' ');
                IceCream _iceCream = new IceCream(_params[0], int.Parse(_params[1]));
                iceCreams.Add(_iceCream);
            }

            return iceCreams;
        }

        public static int SweetestIceCream(List<IceCream> icecream)
        {
            // Write your Code Here
            IceCream ice = new IceCream();
            Console.WriteLine("Enter number of inputs:");
            int input = int.Parse(Console.ReadLine());
            for(int i=0;i<input;i++)
            {
                Console.WriteLine("Enter Falvour:");
                ice.flavour = Console.ReadLine();
                Console.WriteLine("Enter number of sprinkles:");
                ice.num_sprinkles = int.Parse(Console.ReadLine());
                IceCream i = new IceCream(ice.flavour, ice.num_sprinkles);
                icecream.Add(i);
            }
            Icecream ice1 = new IceCream("Chocolate", 13);
            ice1.num_sprinkles += ice1.flavoursweetnesscount();
            int largest = 0;
            foreach(IceCream i in icecream)
            {
                if(i.num_sprinkles>largest)
                {
                    largest = i.num_sprinkles;
                }
            }
            return largest;
        }
    }

    public class IceCream
    {
        // Write your Class Here

        class Icecream
        {
            public string flavour;
            public int num_sprinkles;

            public Icecream(string flavour, int num_sprinkles)
            {
                this.flavour = flavour;
                this.num_sprinkles = num_sprinkles;
            }

            public int flavourssweetnesscount()
            {
                int sweetness_value = 0;
                if (flavour == "Plain")
                {
                    sweetness_value = 0;
                }
                else if (flavour == "Vanilla" || flavour == "ChocolateChip")
                {
                   sweetness_value= 5;
                }
                 else if (flavour == "Strawberry" || flavour == "Chocolate")
                {
                    sweetness_value = 10;
                }
                return sweetness_value;

            }




        }
}