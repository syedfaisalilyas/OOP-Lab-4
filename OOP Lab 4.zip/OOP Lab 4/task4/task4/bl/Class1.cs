﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task4.bl
{
    class Student
    {
        public string StudentName;
        public int FscMarks;
        public int EcatMarks;
        public int StudentAge;
        public float Merit;
        public bool registered = false;
        public string gotadmissionin;
        public List<DegreeProgram> Preferences = new List<DegreeProgram>();
        public List<Subject> regsubject = new List<Subject>();
        public float CalculateAgg()
        {
            float agg = (FscMarks * 0.6F) + (EcatMarks * 0.4F);
            return agg;

        }

        public void GenerateMerit()
        {
            Merit = CalculateAgg();
            int count = 0;
            for (int i = 0; i <= Preferences.Count; i++)
            {
                if (Merit >= Preferences[i].merit)
                {
                    count++;
                    gotadmissionin = Preferences[i].ProgramTitle;
                    registered = true;
                    break;
                }
            }
            if (count == 1)
            {
                Console.WriteLine("{0} got admission in {1}", StudentName, gotadmissionin);
            }
            if (registered == false)
            {
                Console.WriteLine("{0} did not get admission.", StudentName);
            }
        }
        public int getcredithours()
        {
            int count = 0;
            for (int i = 0; i < regsubject.Count; i++)
            {
                count = count + regsubject[i].CreditHours;
            }
            return count;
        }
        public void registersubject(string code)
        {
            int ch = getcredithours();
            for (int i = 0; i < Preferences.Count; i++)
            {
                if (registered == true && gotadmissionin == Preferences[i].ProgramTitle)
                {

                    for (int x = 0; x < Preferences[i].NewSubjects.Count; x++)
                    {
                        if (code == Preferences[i].NewSubjects[x].SubjectCode)
                        {
                            if (ch + Preferences[i].NewSubjects[x].CreditHours <= 9)
                            {
                                regsubject.Add(Preferences[i].NewSubjects[x]);
                                Console.WriteLine("Subject is registered..");
                            }
                            else
                            {
                                Console.WriteLine("A student cannot have more than 9 CH..");
                            }

                        }


                    }
                }
            }
        }
        public float calculatefee()
        {
            int CH = getcredithours();
            return CH * 2000;
        }
    }
}
