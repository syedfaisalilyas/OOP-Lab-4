﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace USMS.BL
{
    class DegreeProgram
    {
        public string programTitle;
        public string programDuration;
        public int availableSeats;
        public float merit;
        public List<Subject> NewSubjects = new List<Subject>();

        public DegreeProgram(string programTitle,string programDuration,int availableSeats,float merit,List<Subject> listofsubjects)
        {
            this.programTitle = programTitle;
            this.programDuration = programDuration;
            this.availableSeats = availableSeats;
            this.merit = merit;
            for(int i=0;i<listofsubjects.Count;i++)
            {
                this.NewSubjects.Add(listofsubjects[i]);
            }
        }

        public DegreeProgram(string programTitle, string programDuration, int availableSeats, float merit)
        {
            this.programTitle = programTitle;
            this.programDuration = programDuration;
            this.availableSeats = availableSeats;
            this.merit = merit;
        }

        public void addsubject(Subject s)
        {
            NewSubjects.Add(s);
        }
    }
}
