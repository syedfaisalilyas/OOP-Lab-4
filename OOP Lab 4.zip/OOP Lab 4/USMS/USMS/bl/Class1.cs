﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace USMS.BL
{
    class Student
    {
        public string StudentName;
        public int age;
        public int FscMarks;
        public int EcatMarrks;
        public bool registered;
        public string gotadmission;
        public float merit;
        public List<DegreeProgram> Preferences = new List<DegreeProgram>();
        public List<Subject> regsubjects = new List<Subject>();
         
        public float calculateaggregate()
        {
            float agg = (FscMarks * 0.6f) + (FscMarks * 0.4f);
            return agg;
        }

        public void GenerateMerit()
        {
            merit = calculateaggregate();
            int count = 0;
            for(int i=0;i<Preferences.Count;i++)
            {
                if(merit>= Preferences[i].merit)
                {
                    count++;
                    registered = true;
                    break;
                }
            }
            if(count == 1)
            {
                Console.WriteLine(" {0} got admission in {1}", StudentName, gotadmission);
            }

            if(registered == false)
            {
                Console.WriteLine(" {0} did not get admission", StudentName);
            }
        }

        public void registersubject(string code)
        {
            int ch = getcredithours();
            for (int i = 0; i < Preferences.Count; i++)
            {
                if (registered == true && gotadmission == Preferences[i].programTitle)
                {

                    for (int x = 0; x < Preferences[i].NewSubjects.Count; x++)
                    {
                        if (code == Preferences[i].NewSubjects[x].Subjectode)
                        {
                            if (ch + Preferences[i].NewSubjects[x].credithours <= 9)
                            {
                                regsubjects.Add(Preferences[i].NewSubjects[x]);
                                Console.WriteLine("Subject is registered..");
                            }
                            else
                            {
                                Console.WriteLine("A student cannot have more than 9 CH..");
                            }

                        }


                    }
                }
            }
        }

        public int getcredithours()
        {
            int count = 0;
            for (int i = 0; i < regsubjects.Count; i++)
            {
                count += regsubjects[i].credithours;
            }
            return count;
        }


        public float calculatefees()
        {
            float ch = getcredithours();
            return ch * 2000;
        }
    }
}
