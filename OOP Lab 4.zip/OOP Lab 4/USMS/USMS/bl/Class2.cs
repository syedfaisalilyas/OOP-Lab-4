﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace USMS.BL
{
    class Subject
    {
        public string Subjectode;
        public string SubjecType;
        public int credithours;
        public int subjectfee;
    }
}
