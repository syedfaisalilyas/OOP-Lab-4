﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using USMS.BL;

namespace USMS
{
    class Program
    {
        static int idx = 0;
        static void Main(string[] args)
        {
            List<Student> StudentList = new List<Student>();
            List<DegreeProgram> ProgramList = new List<DegreeProgram>() ;
            List<DegreeProgram> userListofprograms = new List<DegreeProgram>();
            string name = "";
            string subjectcode = "";
            int option;
            while(true)
            {
                option = Menu();
                if (option == 1)
                {
                    Student s = AddStudentUI(ProgramList);
                    Addstudent(StudentList, s);
                }
                else if (option == 2)
                {
                    DegreeProgram d = AddProgramUI();
                    AddDegree(ProgramList, d);
                }
                else if (option ==3)
                {
                    Generatemerit(StudentList);
                }
                else if(option ==4)
                {
                    ViewRegisteredStudents(StudentList);

                }
                else if(option ==5)
                {
                    Console.WriteLine("Enter Degree program:");
                    string degree = Console.ReadLine();
                    specificdegreeprogram(degree, StudentList);

                }
                else if(option ==6)
                {
                    Console.WriteLine("Enter Student Name:");
                    name = Console.ReadLine();
                    Console.WriteLine("Enter Subject Code:");
                    subjectcode = Console.ReadLine();
                    RegSubject(name, subjectcode, StudentList);
                }
                else if(option ==7)
                {
                    CalculateFee(StudentList);
                }
                else if(option ==8)
                {
                    break;
                }
                Console.WriteLine("Press any key to continue...");
                Console.ReadLine();
                Console.Clear();
            }
        }
        static void CalculateFee(List<Student> StudentList)
        {
            float fees;

            for(int i=0;i<StudentList.Count;i++)
            {
                fees = StudentList[i].calculatefees();
                Console.WriteLine("{0} student fees is {1}",StudentList[i].StudentName,fees);
            }
        }
        static void RegSubject(string name, string code, List<Student> StudentList)
        {
           for(int i=0;i<StudentList.Count;i++)
            {
                if(name==StudentList[i].StudentName)
                {
                    StudentList[i].registersubject(code);
                }
            }
                }


        static void ViewRegisteredStudents(List<Student> StudentList)
        {
            Console.WriteLine("Name\t\tFsc\t\tEcat\t\tAge");
            int count = 0;
            for (int i = 0; i < StudentList.Count;i++)
            {
                Console.WriteLine(StudentList[i].StudentName + "\t\t" + StudentList[i].FscMarks + "\t\t" + StudentList[i].EcatMarrks + "\t\t" + StudentList[i].age);
                count++;
            }
            if(count==0)
            {
                Console.WriteLine("No students are registered yet");

            }
        }

      static void specificdegreeprogram(string degree,List<Student> StudentList)
        {
            Console.WriteLine("Name\t\tFsc\t\tEcat\t\tAge");
            for (int i = 0; i < StudentList.Count; i++)
            {
                if (degree == StudentList[i].gotadmission)
                {
                    Console.WriteLine(StudentList[i].StudentName + "\t\t" + StudentList[i].FscMarks + "\t\t" + StudentList[i].EcatMarrks + "\t\t" + StudentList[i].age);
                }
            }

        }

        static void Generatemerit(List<Student> Studentlist)
        {
            for(int i =0;i<Studentlist.Count;i++)
            {
                Studentlist[i].GenerateMerit();
            }
        }

        static DegreeProgram AddProgramUI()
        {
            List<Subject> listofsub = new List<Subject>();
            string ProgramTitle, DegreeDuration;
            float merit;
            int no_of_subjects;
            int AvailableSeats;
            Console.WriteLine("Enter Degree title:");
            ProgramTitle = Console.ReadLine();
            Console.WriteLine("Enter Degree duration:");
            DegreeDuration = Console.ReadLine();
            Console.WriteLine("Enter no of Available Seats:");
            AvailableSeats = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter merit of this degree program:");
            merit = float.Parse(Console.ReadLine()); ;
            Console.WriteLine("Enter how many subjects to enter:");
            no_of_subjects = int.Parse(Console.ReadLine());
            for(int i=0;i<no_of_subjects;i++)
            {
              Subject s = getsubject();
              listofsub.Add(s);
            }
            DegreeProgram S = new DegreeProgram(ProgramTitle, DegreeDuration, AvailableSeats, merit, listofsub);
            return S;
        }
        static Subject getsubject()
        {
            Subject s = new Subject();

            Console.WriteLine("Enter Subject code:");
            s.Subjectode = Console.ReadLine();
            Console.WriteLine("Enter Subject type:");
            s.SubjecType = Console.ReadLine();
            Console.WriteLine("Enter Credit Hours:");
            s.credithours = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Subject fees:");
            s.subjectfee = int.Parse(Console.ReadLine());
            return s;
        }
        static void AddDegree(List<DegreeProgram> Listofprograms, DegreeProgram P)
        {
            Listofprograms.Add(P);
        }
        static void Addstudent(List<Student> StudentList,Student s)
        {
            StudentList.Add(s);
        }
        static Student AddStudentUI(List<DegreeProgram> ProgramList)
        {

            Student s = new Student();
            int num_pref;
            Console.WriteLine("Enter Student Name:");
            s.StudentName = Console.ReadLine();
            Console.WriteLine("Enter Student Age:");
            s.age = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Student FSC Marks:");
            s.FscMarks = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Student Ecat Marks:");
            s.EcatMarrks = int.Parse(Console.ReadLine());
            Console.WriteLine("Availaible Degree program");
            for(int i=0;i<ProgramList.Count;i++)
            {
                 Console.WriteLine(ProgramList[i].programTitle + "\t");
            }
            Console.WriteLine("Enter how many preferences to enter:");
            num_pref = int.Parse(Console.ReadLine());
            for(int i =0;i<num_pref;i++)
            {
                string pref = takingpref(ProgramList);
                s.Preferences.Add(ProgramList[idx]);
                
            }
            return s;
        }
        
    static string takingpref(List<DegreeProgram> ProgramList)
    {
        string pref = "";
        bool flag = false;
        while (flag != true)
        {
            pref = Console.ReadLine();
            for (int i = 0; i < ProgramList.Count; i++)
            {
                if (pref == ProgramList[i].programTitle)
                {
                    flag = true;
                    idx = i;
                    break;
                }
            }
            if (flag == false)
            {
                Console.WriteLine("You entered wrong input..enter again...");
            }
        }
        return (pref);
    }

    static int Menu()
        {
            int op;
            Console.WriteLine("*******************************************");
            Console.WriteLine("********************UAMS*******************");
            Console.WriteLine("*******************************************");
            Console.WriteLine("1:Add Student");
            Console.WriteLine("2:Add Degree Program");
            Console.WriteLine("3:Generate Merit");
            Console.WriteLine("4:View Registered Students");
            Console.WriteLine("5:View Students of a Specific Program");
            Console.WriteLine("6:Register Subjects For a Specific Student");
            Console.WriteLine("7:Calculate Fees for all Registered Students");
            Console.WriteLine("8:Exit");
            Console.WriteLine("Enter your option");
            op = int.Parse(Console.ReadLine());
            return op;

        }
    }


}






