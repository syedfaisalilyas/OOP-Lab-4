﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.BL
{
    class Player
        {
            public int PX;
            public int PY;

        public Player()
        {

        }
        public Player(int PX,int PY)
        {
            this.PX = PX;
            this.PY = PY;
        }



        public void printspaceship(char[,] player_space_ship, Player p1)
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            for (int rows = 0; rows < 7; rows++)
            {
                Console.SetCursorPosition(p1.PX, p1.PY + rows);
                for (int col = 0; col < 13; col++)
                {
                    Console.Write(player_space_ship[rows, col]);
                }
                Console.WriteLine();
            }
        }
        public void erasespaceship(Player p)
        {
            for (int rows = 0; rows < 7; rows++)
            {
                Console.SetCursorPosition(p.PX, p.PY + rows);
                for (int col = 0; col < 13; col++)
                {
                    Console.Write(" ");
                }
                Console.WriteLine();
            }
        }

        public void moveplayerleft(char[,] Maze, char[,] enemy1_space_ship, char[,] player_space_ship, ref bool gamerunning, Player p1, Enemy1 e1,int enemy1counter, char[,] enemy2_space_ship, char[,] enemy3_space_ship, char[,] enemy4_space_ship, char[,] enemy5_space_ship,Enemy2 e2,Enemy3 e3,Enemy4 e4,Enemy5 e5,int enemy2counter, int enemy3counter, int enemy4counter, int enemy5counter)
        {
            enemy1counter++;
            enemy2counter++;
            enemy3counter++;
            enemy4counter++;
            enemy5counter++;
            if (enemy1counter % 3 == 0)
            {
                moveenemy1(enemy1_space_ship, Maze, ref gamerunning, e1,p1);
            }
            if (enemy2counter % 3 == 0)
            {
                moveenemy2(enemy2_space_ship,Maze,ref gamerunning,e2,p1);
            }
            if (enemy3counter % 3 == 0)
            {
                moveenemy3(enemy3_space_ship,Maze,ref gamerunning,e3,p1);
            }
            if (enemy4counter % 3 == 0)
            {
                moveenemy4(enemy4_space_ship,Maze,ref gamerunning,e4,p1);
            }
            if (enemy5counter % 3 == 0)
            {
                moveenemy5(enemy5_space_ship,Maze,ref gamerunning,e5,p1);
            }

            char next = Maze[p1.PY, p1.PX - 1];
            if (next == ' ')
            {
                erasespaceship(p1);
                p1.PX--;
                printspaceship(player_space_ship, p1);
            }
        }
        public void moveplayerright(char[,] Maze, char[,] enemy1_space_ship, char[,] player_space_ship, ref bool gamerunning, Player p1, Enemy1 e1, int enemy1counter, char[,] enemy2_space_ship, char[,] enemy3_space_ship, char[,] enemy4_space_ship, char[,] enemy5_space_ship, Enemy2 e2, Enemy3 e3, Enemy4 e4, Enemy5 e5, int enemy2counter, int enemy3counter, int enemy4counter, int enemy5counter)
        {
            enemy1counter++;
            enemy2counter++;
            enemy3counter++;
            enemy4counter++;
            enemy5counter++;
            if (enemy1counter % 3 == 0)
            {
                moveenemy1(enemy1_space_ship, Maze, ref gamerunning, e1, p1);
            }
            if (enemy2counter % 3 == 0)
            {
                moveenemy2(enemy2_space_ship, Maze, ref gamerunning, e2, p1);
            }
            if (enemy3counter % 3 == 0)
            {
                moveenemy3(enemy3_space_ship, Maze, ref gamerunning, e3, p1);
            }
            if (enemy4counter % 3 == 0)
            {
                moveenemy4(enemy4_space_ship, Maze, ref gamerunning, e4, p1);
            }
            if (enemy5counter % 3 == 0)
            {
                moveenemy5(enemy5_space_ship, Maze, ref gamerunning, e5, p1);
            }

            char next = Maze[p1.PY, p1.PX + 13];
            if (next == ' ')
            {
                erasespaceship(p1);
                p1.PX++;
                printspaceship(player_space_ship, p1);
            }
        }
        public void moveplayerup(char[,] Maze, char[,] enemy1_space_ship, char[,] player_space_ship, ref bool gamerunning, Player p1, Enemy1 e1, int enemy1counter, char[,] enemy2_space_ship, char[,] enemy3_space_ship, char[,] enemy4_space_ship, char[,] enemy5_space_ship, Enemy2 e2, Enemy3 e3, Enemy4 e4, Enemy5 e5, int enemy2counter, int enemy3counter, int enemy4counter, int enemy5counter)
        {
            enemy1counter++;
            enemy2counter++;
            enemy3counter++;
            enemy4counter++;
            enemy5counter++;
            if (enemy1counter % 3 == 0)
            {
                moveenemy1(enemy1_space_ship, Maze, ref gamerunning, e1, p1);
            }
            if (enemy2counter % 3 == 0)
            {
                moveenemy2(enemy2_space_ship, Maze, ref gamerunning, e2, p1);
            }
            if (enemy3counter % 3 == 0)
            {
                moveenemy3(enemy3_space_ship, Maze, ref gamerunning, e3, p1);
            }
            if (enemy4counter % 3 == 0)
            {
                moveenemy4(enemy4_space_ship, Maze, ref gamerunning, e4, p1);
            }
            if (enemy5counter % 3 == 0)
            {
                moveenemy5(enemy5_space_ship, Maze, ref gamerunning, e5, p1);
            }
       

            char next = Maze[p1.PY - 1, p1.PX];
            if (next == ' ')
            {
                erasespaceship(p1);
                p1.PY--;
                printspaceship(player_space_ship, p1);
            }
        }
        public void moveplayerdown(char[,] Maze, char[,] enemy1_space_ship, char[,] player_space_ship, ref bool gamerunning, Player p1, Enemy1 e1, int enemy1counter, char[,] enemy2_space_ship, char[,] enemy3_space_ship, char[,] enemy4_space_ship, char[,] enemy5_space_ship, Enemy2 e2, Enemy3 e3, Enemy4 e4, Enemy5 e5, int enemy2counter, int enemy3counter, int enemy4counter, int enemy5counter)
        {
            enemy1counter++;
            enemy2counter++;
            enemy3counter++;
            enemy4counter++;
            enemy5counter++;
            if (enemy1counter % 3 == 0)
            {
                moveenemy1(enemy1_space_ship, Maze, ref gamerunning, e1, p1);
            }
            if (enemy2counter % 3 == 0)
            {
                moveenemy2(enemy2_space_ship, Maze, ref gamerunning, e2, p1);
            }
            if (enemy3counter % 3 == 0)
            {
                moveenemy3(enemy3_space_ship, Maze, ref gamerunning, e3, p1);
            }
            if (enemy4counter % 3 == 0)
            {
                moveenemy4(enemy4_space_ship, Maze, ref gamerunning, e4, p1);
            }
            if (enemy5counter % 3 == 0)
            {
                moveenemy5(enemy5_space_ship, Maze, ref gamerunning, e5, p1);
            }
          
            char next = Maze[p1.PY + 7, p1.PX];
            if (next == ' ')
            {
                erasespaceship(p1);
                p1.PY++;
                printspaceship(player_space_ship, p1);
            }
        }

        public void printenemy1(char[,] enemy1_space_ship, Enemy1 e1)
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            for (int rows = 0; rows < 5; rows++)
            {
                Console.SetCursorPosition(e1.E1X, e1.E1Y + rows);
                for (int col = 0; col < 7; col++)
                {
                    Console.Write(enemy1_space_ship[rows, col]);
                }
                Console.WriteLine();
            }
        }
        public void eraseenemy1(Enemy1 e)
        {
            for (int rows = 0; rows < 5; rows++)
            {
                Console.SetCursorPosition(e.E1X, e.E1Y + rows);
                for (int col = 0; col < 7; col++)
                {
                    Console.Write(" ");
                }
                Console.WriteLine();
            }
        }

        public void printenemy2(char[,] enemy2_space_ship, Enemy2 e2)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            for (int rows = 0; rows < 5; rows++)
            {
                Console.SetCursorPosition(e2.E2X, e2.E2Y + rows);
                for (int col = 0; col < 5; col++)
                {
                    Console.Write(enemy2_space_ship[rows, col]);
                }
                Console.WriteLine();
            }
        }

        public void eraseenemy2(Enemy2 e2)
        {
            for (int rows = 0; rows < 5; rows++)
            {
                Console.SetCursorPosition(e2.E2X, e2.E2Y + rows);
                for (int col = 0; col < 5; col++)
                {
                    Console.Write(" ");
                }
                Console.WriteLine();
            }
        }

        public void printenemy3(char[,] enemy3_space_ship, Enemy3 e3)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            for (int rows = 0; rows < 4; rows++)
            {
                Console.SetCursorPosition(e3.E3X, e3.E3Y + rows);
                for (int col = 0; col < 4; col++)
                {
                    Console.Write(enemy3_space_ship[rows, col]);
                }
                Console.WriteLine();
            }
        }

        public void eraseenemy3(Enemy3 e3)
        {
            for (int rows = 0; rows < 4; rows++)
            {
                Console.SetCursorPosition(e3.E3X, e3.E3Y + rows);
                for (int col = 0; col < 4; col++)
                {
                    Console.Write(" ");
                }
                Console.WriteLine();
            }
        }

        public void printenemy4(char[,] enemy4_space_ship, Enemy4 e4)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            for (int rows = 0; rows < 6; rows++)
            {
                Console.SetCursorPosition(e4.E4X, e4.E4Y + rows);
                for (int col = 0; col < 7; col++)
                {
                    Console.Write(enemy4_space_ship[rows, col]);
                }
                Console.WriteLine();
            }
        }

        public void eraseenemy4(Enemy4 e4)
        {
            for (int rows = 0; rows < 6; rows++)
            {
                Console.SetCursorPosition(e4.E4X, e4.E4Y + rows);
                for (int col = 0; col < 7; col++)
                {
                    Console.Write(" ");
                }
                Console.WriteLine();
            }
        }

        public void printenemy5(char[,] enemy5_space_ship, Enemy5 e5)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            for (int rows = 0; rows < 4; rows++)
            {
                Console.SetCursorPosition(e5.E5X, e5.E5Y + rows);
                for (int col = 0; col < 4; col++)
                {
                    Console.Write(enemy5_space_ship[rows, col]);
                }
                Console.WriteLine();
            }
        }
       public void eraseenemy5(Enemy5 e5)
        {
            Console.ForegroundColor = ConsoleColor.Black;
            for (int rows = 0; rows < 4; rows++)
            {
                Console.SetCursorPosition(e5.E5X, e5.E5Y + rows);
                for (int col = 0; col < 4; col++)
                {
                    Console.Write(" ");
                }
                Console.WriteLine();
            }
        }


        public void printlaka(char[,] Maze,ref bool gamerunning, Enemy1 e1)
        {
            for (int i = 0; i < 6; i++)
            {
               char next = Maze[e1.E1Y + 5, e1.E1X + i];
                if (next == '_' || next == '\\' || next == '/' || next == '|')
                {
                    gamerunning = false;

                    /*      loselife();
                          updatelives();*/
                }
            }
        }

       public void moveenemy3(char[,] enemy3_space_ship, char[,] Maze, ref bool gamerunning, Enemy3 e3, Player p1)
        {

            if (e3.direction== "down")
            {
                char next = Maze[e3.E3X, e3.E3Y + 4];
                if (next == ' ')
                {
                    eraseenemy3(e3);
                    e3.E3Y++;
                    printenemy3(enemy3_space_ship,e3);
                }
                if (next == '+')
                {
                    eraseenemy3(e3);
                    e3.E3Y = 1;
                    printenemy3(enemy3_space_ship,e3);
                }
                else if (e3.E3X >= p1.PX && e3.E3X < p1.PX + 13 && e3.E3Y >= p1.PY && e3.E3Y < p1.PY + 7)
                {
                    gamerunning = false;
                }
            }
        }
       public void moveenemy4(char[,] enemy4_space_ship, char[,] Maze, ref bool gamerunning, Enemy4 e4, Player p1)
        {

            if (e4.direction == "down")
            {
                char next = Maze[e4.E4X, e4.E4Y + 6];
                if (next == ' ')
                {
                    eraseenemy4(e4);
                    e4.E4Y++;
                    printenemy4(enemy4_space_ship,e4);
                }
                if (next == '+')
                {
                    eraseenemy4(e4);
                    e4.E4Y = 1;
                    printenemy4(enemy4_space_ship,e4);
                }
                else if (e4.E4X >= p1.PX && e4.E4X < p1.PX + 13 && e4.E4Y >= p1.PY && e4.E4Y < p1.PY + 7)
                {
                    gamerunning = false;
                }

            }
        }
       public void moveenemy5(char[,] enemy5_space_ship, char[,] Maze, ref bool gamerunning, Enemy5 e5, Player p1)
        {

            if (e5.direction == "down")
            {
                char next = Maze[e5.E5X, e5.E5Y + 4];
                if (next == ' ')
                {
                    eraseenemy5(e5);
                    e5.E5Y++;
                    printenemy5(enemy5_space_ship,e5);
                }
                if (next == '+')
                {
                    eraseenemy5(e5);
                    e5.E5Y = 1;
                    printenemy5(enemy5_space_ship,e5);
                }
                else if (e5.E5X >= p1.PX && e5.E5X < p1.PX + 13 && e5.E5Y >= p1.PY && e5.E5Y < p1.PY + 7)
                {
                    gamerunning = false;
                }
            }
        }

        public void moveenemy2(char[,] enemy2_space_ship, char[,] Maze, ref bool gamerunning, Enemy2 e2, Player p1)
        {

            if (e2.direction == "down")
            {
                char next = Maze[e2.E2X, e2.E2Y + 5];

                if (next == ' ')
                {
                    eraseenemy2(e2);
                    e2.E2Y++;
                    printenemy2(enemy2_space_ship,e2);
                }
                else if (next == '+')
                {
                    eraseenemy2(e2);
                    e2.E2Y = 4;
                    printenemy2(enemy2_space_ship,e2);
                }
                else if (e2.E2X >= p1.PX && e2.E2X < p1.PX + 13 && e2.E2Y >= p1.PY && e2.E2Y < p1.PY + 7)
                {
                    gamerunning = false;
                }

                else
                {
                    for (int i = 0; i < 6; i++)
                    {
                         next = Maze[e2.E2Y + 5, e2.E2X + i];
                        if (next == '_' || next == '\\' || next == '/' || next == '|')
                        {
                            gamerunning = false;

                            /*      loselife();
                                  updatelives();*/
                        }
                    }

                }

            }
        }
        public void moveenemy1(char[,] enemy1_space_ship, char[,] Maze, ref bool gamerunning, Enemy1 e1,Player p1)
        {

            if (e1.direction == "down")
            {
                char next = Maze[e1.E1Y + 5, e1.E1X];
                if (next == ' ')
                {
                    eraseenemy1(e1);
                    e1.E1Y++;
                    printenemy1(enemy1_space_ship, e1);
                }
               else if (next == '+')
                {
                    eraseenemy1(e1);
                    e1.E1Y = 1;
                    printenemy1(enemy1_space_ship, e1);
                }
                else if(e1.E1X >= p1.PX && e1.E1X < p1.PX + 13 && e1.E1Y >= p1.PY && e1.E1Y < p1.PY + 7)
                    {
                    gamerunning = false;
                }
                else
                {

                    printlaka(Maze,ref gamerunning, e1);
                }
            }
        }


    }
}
