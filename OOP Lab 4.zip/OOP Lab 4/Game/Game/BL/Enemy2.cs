﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.BL
{
    class Enemy2
    {
        public int E2X;
        public int E2Y;
        public string direction;

        public Enemy2()
        {

        }
        public Enemy2(int E2X,int E2Y,string direction)
        {
            this.E2X = E2X;
            this.E2Y = E2Y;
            this.direction = direction;
        }
    }
}
