﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.BL
{
    class Enemy3
    {
        public int E3X;
        public int E3Y;
        public string direction;

        public Enemy3()
        {

        }
        public Enemy3(int E3X, int E3Y, string direction)
        {
            this.E3X = E3X;
            this.E3Y = E3Y;
            this.direction = direction;
        }
    }
}
