﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.BL
{
    class Enemy5
    {
        public int E5X;
        public int E5Y;
        public string direction;
        public Enemy5()
        {

        }
        public Enemy5(int E5X, int E5Y, string direction)
        {
            this.E5X = E5X;
            this.E5Y = E5Y;
            this.direction = direction;
        }
    }
}
