﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.BL
{
    class Enemy1
    {
        public int E1X;
        public int E1Y;
        public string direction;

        public Enemy1()
        {
        }

        public Enemy1(int E1X, int E1Y, string direction)
        {
            this.E1X = E1X;
            this.E1Y = E1Y;
            this.direction = direction;

        }




    }
    
}
