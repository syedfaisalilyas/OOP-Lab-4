﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.BL
{
    class Enemy4
    {
        public int E4X;
        public int E4Y;
        public string direction;


        public Enemy4()
        {

        }
        public Enemy4(int E4X, int E4Y, string direction)
        {
            this.E4X = E4X;
            this.E4Y = E4Y;
            this.direction = direction;
        }
    }
}
