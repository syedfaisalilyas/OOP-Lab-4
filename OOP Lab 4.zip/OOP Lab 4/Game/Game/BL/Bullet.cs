﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.BL
{
    class Bullet
    {
        public int bulletx;
        public int bullety;
        public bool isbulletactive;
    }
}
