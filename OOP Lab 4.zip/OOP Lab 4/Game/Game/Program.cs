﻿using Game.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EZInput;
using System.Threading;
using System.IO;
using System.Threading.Tasks;

namespace Game
{
    class Program
    {
        static char bulletchar = (char)30;

        static void Main(string[] args)
        {

            int enemy1counter = 0;
            int enemy2counter = 0;
            int enemy3counter = 0;
            int enemy4counter = 0;
            int enemy5counter = 0;
           
            int PX = 30;
            int PY = 23;
            Player p1 = new Player(PX, PY);
            int E1X = 16;
            int E1Y = 15;
            int E5X = 50;
            int E5Y = 10;
            int E2X = 108;
            int E2Y = 2;
            int E3X = 140;
            int E3Y = 20;
            int E4X = 76;
            int E4Y = 16;
            string direction = "down";
            Enemy1 e1 = new Enemy1(E1X, E1Y, direction);
            Enemy2 e2 = new Enemy2(E2X, E2Y, direction);
            Enemy3 e3 = new Enemy3(E3X, E3Y, direction);
            Enemy4 e4 = new Enemy4(E4X, E4Y, direction);
            Enemy5 e5 = new Enemy5(E5X, E5Y, direction);
            List<Bullet> b = new List<Bullet>();
            List<Bullet> bulletx = new List<Bullet>();
            List<Bullet> bullety = new List<Bullet>();
            char[,] player_space_ship = new char[7, 13]
    {
    {' ', ' ', ' ', ' ', ' ', ' ', '_', ' ', ' ', ' ', ' ', ' ', ' '},
    {' ', ' ', ' ', ' ', ' ', '/', ' ', '\\', ' ', ' ', ' ', ' ', ' '},
    {' ', ' ', ' ', ' ', '/', ' ', '_', ' ', '\\', ' ', ' ', ' ', ' '},
    {' ', ' ', ' ', '/', ' ', ' ', '_', ' ', ' ', '\\', ' ', ' ', ' '},
    {' ', '_', '/', ' ', ' ', ' ', '_', ' ', ' ', ' ', '\\', '_', ' '},
    {'|', '_', '_', '_', '_', ' ', ' ', ' ', '_', '_', '_', '_', '|'},
    {' ', ' ', ' ', ' ', ' ', '\\', '_', '/', ' ', ' ', ' ', ' ', ' '}
   };
            char[,] enemy2_space_ship = new char[,]
{
    {' ', ' ', '_', ' ', ' '},
    {' ', '|', 'o', '|', ' '},
    {' ', '(', '|', ')', ' '},
    {' ', '/', '|', '\\', ' '},
    {'/', ' ', '|', ' ', '\\'}
};

            char[,] enemy3_space_ship = new char[,]
            {
    {'_', '^', '^', '_'},
    {'*', '*', '*', '*'},
    {'*', '*', '*', '*'},
    {'.', '*', '*', '.'}
            };

            char[,] enemy4_space_ship = new char[,]
            {
    {' ', ' ', '_', '_', ' ', ' ', ' '},
    {' ', '/', ' ', ' ', '\\', ' ', ' '},
    {'-', '|', ' ', ' ', '|', '-', ' '},
    {'/', ' ', '%', ' ', '%', ' ', '\\'},
    {' ', ':', ' ', ' ', ' ', ':', ' '},
    {' ', ' ', '^', '-', '^', ' ', ' '}
            };
            char character = (char)219;

            char[,] enemy5_space_ship = new char[,]
            {
    {character, character, character, character},
    {character, character, character, character},
    {character, character, character, character},
    {' ', '\\', '/', ' '}
            };


            char[,] enemy1_space_ship = new char[5, 7]{
                                { ' ', ' ', '*', '*', '*', ' ', ' '},
                                { '*', '*', '*', '*', '*', '*', '*'},
                                { '*', '*', '*', '*', '*', '*', '*'},
                                { ' ', '*', '*', '*', '*', '*', ' '},
                                { ' ', ' ', '*', '*', '*', ' ', ' '}
            };

            char[,] Maze = new char[40, 180];



            Console.CursorVisible = false;
            Console.Clear();

            int currentSelection = 1;
            Console.ForegroundColor = ConsoleColor.White;
            while (true)
            {
                Console.Clear();
                Logo();

                if (currentSelection == 1)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.Write("  >");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("   ");
                }
                Console.WriteLine("   Play");

                if (currentSelection == 2)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.Write("  >");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("   ");
                }
                Console.WriteLine("   Instructions");

                if (currentSelection == 3)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.Write("  >");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("   ");
                }
                Console.WriteLine("   Exit");

                // handle user input
                ConsoleKeyInfo key = Console.ReadKey(true);

                if (key.Key == ConsoleKey.UpArrow)
                { // up arrow key
                    if (currentSelection > 1)
                    {
                        currentSelection--;
                    }
                    else if (currentSelection == 1)
                    {
                        currentSelection = 3;
                    }
                }
                else if (key.Key == ConsoleKey.DownArrow)
                { // down arrow key
                    if (currentSelection < 3)
                    {
                        currentSelection++;
                    }
                    else if (currentSelection == 3)
                    {
                        currentSelection = 1;
                    }
                }
                else if (key.Key == ConsoleKey.Enter)
                { // enter key
                    if (currentSelection == 1)
                    {
                        Play(player_space_ship, enemy1_space_ship, Maze, b, p1, e1, bulletx, bullety, enemy1counter,enemy2counter,enemy3counter,enemy4counter,enemy5counter,enemy2_space_ship,enemy3_space_ship,enemy4_space_ship,enemy5_space_ship,e2,e3,e4,e5);
                    }
                    else if (currentSelection == 2)
                    {
                        Console.Clear();
                        Instructions();
                        Console.ReadKey(true); // wait for user input before going back to main screen
                    }
                    else if (currentSelection == 3)
                    {
                        Environment.Exit(0);
                    }
                }
            }


        }


        // ----Play---
        static void Play(char[,] player_space_ship, char[,] enemy1_space_ship, char[,] Maze, List<Bullet> b, Player p1, Enemy1 e1, List<Bullet> bulletx, List<Bullet> bullety, int enemy1counter, int enemy2counter, int enemy3counter, int enemy4counter, int enemy5counter, char[,] enemy2_space_ship, char[,] enemy3_space_ship, char[,] enemy4_space_ship, char[,] enemy5_space_ship,Enemy2 e2,Enemy3 e3,Enemy4 e4,Enemy5
            e5)
        {
            /*readscore();*/
            Console.Clear();
            history();
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            bool gamerunning = true;

            Console.Clear();
            /*            readData(Maze);
                        printMaze(Maze);*/

            DrawBorder(Maze);
            /*            controlmenu();
                        updatescore();
                        updatelives();*/
            p1.printspaceship(player_space_ship, p1);
            p1.printenemy1(enemy1_space_ship, e1);
            p1.printenemy2(enemy2_space_ship, e2);
            p1.printenemy3(enemy3_space_ship, e3);
            p1.printenemy4(enemy4_space_ship, e4);
            p1.printenemy5(enemy5_space_ship, e5);
            while (gamerunning)
            {
                enemy1counter++;

                p1.moveenemy1(enemy1_space_ship, Maze, ref gamerunning, e1,p1);
                p1.moveenemy2(enemy2_space_ship, Maze, ref gamerunning, e2, p1);
                p1.moveenemy3(enemy3_space_ship, Maze, ref gamerunning, e3, p1);
                p1.moveenemy4(enemy4_space_ship, Maze, ref gamerunning, e4, p1);
                p1.moveenemy5(enemy5_space_ship, Maze, ref gamerunning, e5, p1);

                if (Keyboard.IsKeyPressed(Key.LeftArrow))
                {
                    p1.moveplayerleft(Maze, enemy1_space_ship, player_space_ship, ref gamerunning, p1, e1, enemy1counter,enemy2_space_ship,enemy3_space_ship,enemy4_space_ship,enemy5_space_ship,e2,e3,e4,e5,enemy2counter,enemy3counter,enemy4counter,enemy5counter);
                }
                if (Keyboard.IsKeyPressed(Key.RightArrow))
                {
                    p1.moveplayerright(Maze, enemy1_space_ship, player_space_ship, ref gamerunning, p1, e1, enemy1counter, enemy2_space_ship, enemy3_space_ship, enemy4_space_ship, enemy5_space_ship, e2, e3, e4, e5, enemy2counter, enemy3counter, enemy4counter, enemy5counter);
                }
                if (Keyboard.IsKeyPressed(Key.UpArrow))
                {
                    p1.moveplayerup(Maze, enemy1_space_ship, player_space_ship, ref gamerunning, p1, e1, enemy1counter, enemy2_space_ship, enemy3_space_ship, enemy4_space_ship, enemy5_space_ship, e2, e3, e4, e5, enemy2counter, enemy3counter, enemy4counter, enemy5counter);
                }
                if (Keyboard.IsKeyPressed(Key.DownArrow))
                {
                    p1.moveplayerdown(Maze, enemy1_space_ship, player_space_ship, ref gamerunning, p1, e1, enemy1counter,enemy2_space_ship,enemy3_space_ship,enemy4_space_ship,enemy5_space_ship,e2,e3,e4,e5,enemy2counter,enemy3counter,enemy4counter,enemy5counter);
                }
                if (Keyboard.IsKeyPressed(Key.Space))
                {
                    generatebullet(b, p1);

                }
                if (Keyboard.IsKeyPressed(Key.Escape))
                {
                    gamerunning = false;
                }
                if (gamerunning == false)
                {
                    Console.Clear();
                    Environment.Exit(0);
                    /*gameover();*/
                    /*                    Score[score_count] = score;
                                        storescore(Score[score_count]);
                                        score_count++;*/
                }
                movebullet(b, Maze, bulletx, bullety); // to move bullets
                bulletcollisionwidenemy(b, enemy1_space_ship, Maze, ref gamerunning, e1, p1);
                Thread.Sleep(15); // to slow the game speed if you want to move the enemies fast the pass the small value to small function like 1 , 2 ,3 and same for slow pass the larger value like 50 or  70
            }
        }


        // ---Collision---
        static void bulletcollisionwidenemy(List<Bullet> b, char[,] enemy1_space_ship, char[,] Maze, ref bool gamerunning, Enemy1 e1, Player p1)
        {
            for (int x = 0; x < b.Count; x++)
            {
                if (b[x].isbulletactive == true)
                {
                    if (b[x].bullety == e1.E1Y + 5 && (b[x].bullety == e1.E1X || b[x].bulletx == e1.E1X + 1 || b[x].bulletx == e1.E1X + 2 || b[x].bulletx == e1.E1X + 3 || b[x].bulletx == e1.E1X + 4 || b[x].bulletx == e1.E1X + 5 || b[x].bulletx == e1.E1X + 6))
                    {
                        p1.eraseenemy1(e1);
                        /*     addscore();
                             updatescore();*/
                        Random rnd = new Random();
                        int randomno = rnd.Next();
                        e1.E1X = randomno % 100;
                        e1.E1Y = 2;
                        p1.moveenemy1(enemy1_space_ship, Maze, ref gamerunning, e1,p1);
                    }

                }
            }
        }

        static void generatebullet(List<Bullet> b, Player p1)
        {
            Bullet b1 = new Bullet();
            b1.bulletx = p1.PX + 6;
            b1.bullety = p1.PY - 1;
            b1.isbulletactive = true;
            Console.SetCursorPosition(b1.bulletx, b1.bullety);
            Console.Write(bulletchar);
            b.Add(b1);
        }
        static void movebullet(List<Bullet> b, char[,] Maze, List<Bullet> bulletx, List<Bullet> bullety)
        {

            for (int x = 0; x < b.Count; x++)
            {
                /*     if (isBulletActive[x] = true)
                     { */
                char next = Maze[b[x].bullety - 1, b[x].bulletx]; // get the next possition of bullet if valid the move the bullets else remove it
                if (next == ' ')                                     // to check the conditions if you want to add the collision of bullet with enemy then simply add the enemy char with or (||) operater in if statement  of enemy remove function in if body
                {
                    erasebullet(b[x].bulletx, b[x].bullety);
                    b[x].bullety--;
                    printbullet(b[x].bulletx, b[x].bullety);
                }
                else // remove the bullets
                {
                    erasebullet(b[x].bulletx, b[x].bullety);
                    makebulletInactive(x, b);
                    deletebullet(x, bulletx, bullety);

                    /*}*/
                }
            }
        }
        static void printbullet(int x, int y)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.SetCursorPosition(x, y);
            Console.Write(bulletchar);
        }
        static void erasebullet(int x, int y)
        {
            Console.SetCursorPosition(x, y);
            Console.Write(' ');
        }
        static void makebulletInactive(int index, List<Bullet> b)
        {
            b[index].isbulletactive = false;
        }
        static void deletebullet(int index, List<Bullet> bulletx, List<Bullet> bullety)
        {
            if (index < 0)
            {
                bulletx.RemoveAt(index);
                bullety.RemoveAt(index);
            }
        }



        // ----- Moving Players Functions ----



        static void readData(char[,] maze2)
        {
            StreamReader fp = new StreamReader("C:\\OOP\\OOP Lab 1\\game\\game\\game\\maze.txt");
            string record;
            int row = 0;
            while ((record = fp.ReadLine()) != null)
            {
                for (int x = 0; x < 180; x++)
                {
                    maze2[row, x] = record[x];
                }
                row++;
            }

            fp.Close();
        }

        static void printMaze(char[,] maze)
        {
            Console.ForegroundColor = ConsoleColor.Gray;

            for (int x = 0; x < maze.GetLength(0); x++)
            {
                for (int y = 0; y < maze.GetLength(1); y++)
                {
                    Console.Write(maze[x, y]);
                }
                Console.WriteLine();
            }
        }

        // ----Drawing border-----
        static void DrawBorder(char[,] Maze)
        {
            Console.ForegroundColor = ConsoleColor.Gray;

            for (int x = 0; x < 40; x++)
            {
                for (int y = 0; y < 180; y++)
                {
                    if (x == 0 || x == 39 || y == 0 || y == 179)
                    {
                        Maze[x, y] = '+';
                    }
                    else if (y == 150 && x < 39 && x > 0)

                    {
                        Maze[x, y] = '+';
                    }
                    else
                    {
                        Maze[x, y] = ' ';
                    }
                    Console.Write(Maze[x, y]);
                }
                Console.WriteLine();
            }

        }

        static void Logo()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n\n\n");
            Console.WriteLine("    $$$$$$\\  $$$$$$$\\   $$$$$$\\   $$$$$$\\  $$$$$$$$\\        $$$$$$\\  $$\\   $$\\  $$$$$$\\   $$$$$$\\ $$$$$$$$\\ $$$$$$$$\\ $$$$$$$\\  ");
            Console.WriteLine("   $$  _$$\\ $$  _$$\\ $$  _$$\\ $$  _$$\\ $$  __|      $$  _$$\\ $$ |  $$ |$$  _$$\\ $$  _$$\\_$$  _|$$  __|$$  _$$\\ ");
            Console.WriteLine("   $$ /  \\_|$$ |  $$ |$$ /  $$ |$$ /  \\|$$ |            $$ /  \\_|$$ |  $$ |$$ /  $$ |$$ /  $$ |  $$ |   $$ |      $$ |  $$ |");
            Console.WriteLine("   \\$$$$$$\\  $$$$$$$  |$$$$$$$$ |$$ |      $$$$$\\          \\$$$$$$\\  $$$$$$$$ |$$ |  $$ |$$ |  $$ |  $$ |   $$$$$\\    $$$$$$$  |");
            Console.WriteLine("    \\__$$\\ $$  _/ $$  _$$ |$$ |      $$  _|          \\_$$\\ $$  _$$ |$$ |  $$ |$$ |  $$ |  $$ |   $$  _|   $$  __$$< ");
            Console.WriteLine("   $$\\   $$ |$$ |      $$ |  $$ |$$ |  $$\\ $$ |            $$\\   $$ |$$ |  $$ |$$ |  $$ |$$ |  $$ |  $$ |   $$ |      $$ |  $$ |");
            Console.WriteLine("   \\$$$$$$  |$$ |      $$ |  $$ |\\$$$$$$  |$$$$$$$$\\       \\$$$$$$  |$$ |  $$ | $$$$$$  | $$$$$$  |  $$ |   $$$$$$$$\\ $$ |  $$ |");
            Console.WriteLine("    \\___/ \\|      \\|  \\| \\__/ \\__|       \\__/ \\|  \\| \\__/  \\__/   \\|   \\__|\\|  \\_|\n\n\n");

            // Reset the console color to default
            Console.ResetColor();
        }

        static void Instructions()
        {
            int x = 40;
            int y = 10;
            Console.BackgroundColor = ConsoleColor.DarkMagenta;
            Console.WriteLine("\n\n");

            Console.SetCursorPosition(x + 15, y - 5);
            Console.WriteLine("*********");
            Console.SetCursorPosition(x + 15, y - 4);
            Console.WriteLine("     Space Shooter Game");
            Console.SetCursorPosition(x + 15, y - 3);
            Console.WriteLine("*********");
            Console.WriteLine("\n\n");

            Console.SetCursorPosition(x, y);
            Console.WriteLine("Instructions");
            Console.WriteLine("\n\n");
            Console.SetCursorPosition(x, y + 1);
            Console.WriteLine("1. Use the arrow keys to move your spaceship left and right.");
            Console.SetCursorPosition(x, y + 2);
            Console.WriteLine("2. Press the space bar to fire bullets at the enemy spaceships.");
            Console.SetCursorPosition(x, y + 3);
            Console.WriteLine("3. Avoid getting hit by enemy bullets or colliding with their spaceships.");
            Console.SetCursorPosition(x, y + 4);
            Console.WriteLine("4. Shoot down as many enemy spaceships as possible to score points.");
            Console.SetCursorPosition(x, y + 5);
            Console.WriteLine("5. The game will display your score on the right side of the console.");
            Console.SetCursorPosition(x, y + 6);
            Console.WriteLine("6. Press any key to go back to the main screen.");
        }

        static void Loading()
        {
            // this is just a loading bar

            Console.SetCursorPosition(87, 26);
            Console.WriteLine("LOADING....");
            int x, y;

            // HORIZONTAL
            //--UP
            x = 87;
            y = 27;
            Console.SetCursorPosition(x, y);
            for (int z = 0; z <= 30; z++)
            {
                Console.Write((char)205);
            }
            //--Down
            y = 29;
            Console.SetCursorPosition(x, y);
            for (int z = 0; z <= 30; z++)
            {
                Console.Write((char)205);
            }

            // VERTICAL
            //--Right
            x = 117;
            Console.SetCursorPosition(x, y);
            for (y = 28; y < 29; y++)
            {
                Console.SetCursorPosition(x, y);
                Console.Write((char)186);
            }
            //--Left
            x = 87;
            Console.SetCursorPosition(x, y);
            for (y = 28; y < 29; y++)
            {
                Console.SetCursorPosition(x, y);
                Console.Write((char)186);
            }

            // Corners
            Console.SetCursorPosition(87, 27);
            Console.Write((char)201); // UP -LEFT
            Console.SetCursorPosition(117, 27);
            Console.Write((char)187); // UP - RIGHT
            Console.SetCursorPosition(87, 29);
            Console.Write((char)200); // DOWN -LEFT
            Console.SetCursorPosition(117, 29);
            Console.Write((char)188); // DOWN RIGHT

            // Loading bar
            for (int cargar = 88; cargar < 117; cargar++)
            {
                Console.SetCursorPosition(cargar, 28);
                Console.Write((char)178);

                Thread.Sleep(50);
            }
        }

        static void history()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;

            // Story
            int x = 48, y = 3;
            Console.SetCursorPosition(x, y);
            Console.Write("WELCOME TO SPACE SHOOTER GAME");
            x = 12; y = 5;
            Console.SetCursorPosition(x, y);
            Console.Write("The galaxy is under Attack, an alien race called 'The Yincas' has invaded our solar");
            Console.SetCursorPosition(x, y + 1);
            Console.Write(" system and it is taking the earth's resources.  If we don't do something the human");
            Console.SetCursorPosition(x, y + 2);
            Console.Write("race will disappear.");

            Console.SetCursorPosition(x, y + 4);
            Console.Write("YOUR MISION:");
            Console.SetCursorPosition(x, y + 5);
            Console.Write("Destroy some yinca ships to show them we are not afraid");
            Console.SetCursorPosition(x, y + 7);
            Console.Write("VEHICLE:");
            Console.SetCursorPosition(x, y + 8);
            Console.Write("You've got the StarFighter spaceship, use the left,right,up and down keys to move it");
            Console.SetCursorPosition(x, y + 10);
            Console.Write("TECHNOLOGY:");
            Console.SetCursorPosition(x, y + 11);
            Console.Write("We have a laser gun, to shoot it use the spaceBar");
            x = 33; y = 20;
            Console.SetCursorPosition(x, y);
            Console.Write("OK SOLDIER, HIT ENTER TO JUMP INTO THE ACTION!!!");

            Loading(); // LOADING BAR

            Console.ReadKey(true); // WAIT FOR ANY KEY TO BE PRESSED TO CLEAN THE SCREEN
            Console.Clear();
        }
    }
}
