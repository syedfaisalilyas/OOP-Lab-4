﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using task2.bl;

namespace task2
{  
        class Program
        {
            static void Main(string[] args)
            {
                List<Book> books = new List<Book>();
                Book b1 = new Book();

               
                b1 = AddBook();
                books.Add(b1);


                settingBookMark();
                Console.WriteLine(b1.bookMark);
                settingPrice();
                Console.WriteLine(b1.price);

                Console.WriteLine(b1.getBookMark());
                Console.WriteLine(b1.getPrice());
                Console.ReadLine();
            }
            static Book AddBook()
            {
                int numberOfChapters;
                Book b1 = new Book();
                Console.WriteLine("Enter name of author: ");
                b1.author = Console.ReadLine();
                Console.WriteLine("Enter number of pages:");
                b1.pages = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter number of chapters you wanted to enter");
                numberOfChapters = int.Parse(Console.ReadLine());
                for (int i = 0; i < numberOfChapters; i++)
                {
                    Console.WriteLine("Enter name of chapters");
                    b1.AddChapter(Console.ReadLine());
                }

                Console.WriteLine("Enter book price");
                b1.price = int.Parse(Console.ReadLine());
                return b1;
            }
            static void settingBookMark()
            {
                int bmark;
                Book b1 = new Book();
                Console.WriteLine("Enter the page number at which you wanted to add book mark:");
                bmark = int.Parse(Console.ReadLine());
                b1.setBookMark(bmark);
            }
            static void settingPrice()
            {
                int price;
                Book b1 = new Book();
                Console.WriteLine("Enter book price");
                price = int.Parse(Console.ReadLine());
                b1.setBookPrice(price);
            }
        }
    }














