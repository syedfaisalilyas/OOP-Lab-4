﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task2.bl
{
    class Book
    {
        public string author;
        public int pages;
        public List<string> Chapters = new List<string>();
        public int bookMark;
        public int price;

        public Book()
        {

        }
        public Book(string author, int pages, List<string> Chapters, int bookMark, int pricr)
        {
            this.author = author;
            this.pages = pages;
            this.Chapters = Chapters;
            this.bookMark = bookMark;
            this.price = price;
        }

        public string getChapter(int chapternumber)
        {
            string chaptername = "";
            for (int i = 0; i < Chapters.Count; i++)
            {
                if (i == chapternumber)
                {
                    chaptername = Chapters[i];
                }
            }
            return chaptername;
        }

        public int getBookMark()
        {
            return bookMark;
        }

        public void setBookMark(int pagenumber)
        {
            bookMark = pagenumber;
        }

        public int getBookPrice()
        {
            return price;
        }

        public void setBookPrice(int newPrice)
        {
            price = newPrice;
        }

        public void addtolist(string name)
        {
            Chapters.Add(name);
        }
        }
    }






