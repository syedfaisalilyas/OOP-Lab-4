﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task1.bl
{
    public class Student
    {
        public string Name;
        public int rollNumber;
        public float cGPA;
        public int matricMarks;
        public int FscMarks;
        public int EcatMarks;
        public string HomeTown;
        public bool isHostelite;
        public bool isTakingSCHOLARSHIP;


        public Student()
        {
            Name = "";
            rollNumber = 63;
            cGPA = 4.0f;
            FscMarks = 100;
            matricMarks = 100;


        }
        public Student(string Name,int rollNumber,float cGPA,int matricMarks, int FscMarks, int EcatMarks,string HomeTown,bool isHostelite,bool isTakingSCHOLARSHIP)
        {
            this.Name = Name;
            this.rollNumber = rollNumber;
            this.cGPA = cGPA;
            this.matricMarks = matricMarks;
            this.FscMarks = FscMarks;
            this.EcatMarks = EcatMarks;
            this.HomeTown = HomeTown;
            this.isHostelite = isHostelite;
            this.isTakingSCHOLARSHIP = isTakingSCHOLARSHIP;
        }

        public float calculateMerit()
        {
            float marks = (60 * matricMarks) / 100 + (40 * EcatMarks) / 100;
            return marks;
        }

        public bool isEligibleForScholarship(float marks)
        {
            if(isHostelite)
            {
            if(marks>80 )
                {
                    return true;
                }
    
            }
            return false;
        }

    }
}
