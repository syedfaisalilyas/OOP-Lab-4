﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using task1.bl;

namespace task1
{
    class Program
    {
        static void Main(string[] args)
        {
         List<Student> sl = new List<Student>();

        int option;
            do
            {
                Console.WriteLine("1.Enter Your Data:");
                Console.WriteLine("2.Check if you are eligible for a scholarship:");
                Console.WriteLine("3.Chcek merit:");
                Console.WriteLine("4.Press any key to Exit:");
                Console.WriteLine("Enter Option:");
                option = int.Parse(Console.ReadLine());

                if (option == 1)
                {
                    Student s = AddStudent();
                    addtolist(sl, s);
                }
                else if (option == 2)
                {
                    foreach (Student i in sl)
                    {
                        if (i.isEligibleForScholarship(i.calculateMerit()))
                            {
                            Console.WriteLine(i.Name);
                        }

                    }
                }
                if(option == 3)
                {
                    foreach(Student i in sl)
                    {
                     float per = i.calculateMerit();
                    Console.WriteLine("Your merit Percentage is: " + per + "%");

                    }
    }

}
            while (option != 4);
            Console.ReadLine();
        }

        static Student AddStudent()
        {
            int fMarks, mMarks, eMarks;
            Console.WriteLine("Enter Name of Student:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter roll number:");
            int rollNumber = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter matric marks");
            mMarks = int.Parse(Console.ReadLine());
            while (!(mMarks >=0 && mMarks<= 1100))
            {
                Console.WriteLine("Enter matric marks");
                mMarks = int.Parse(Console.ReadLine());
            }
            
            Console.WriteLine("Enter fsc marks");
            fMarks = int.Parse(Console.ReadLine());
            while (!(fMarks>=0 && fMarks <= 1100))
            {
                Console.WriteLine("Enter matric marks");
                fMarks = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Enter ecat marks");
            eMarks = int.Parse(Console.ReadLine());
            while (!(eMarks>=0 && eMarks <= 400))
            {
                Console.WriteLine("Enter matric marks");
                eMarks = int.Parse(Console.ReadLine());
            }


            Console.WriteLine("Enter cGPA");
            float cgpa = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter hometown of the student");
            string homeTown = Console.ReadLine();

            Console.WriteLine("Is student hostilite or not!(Enter \"true\" if yes \"false\" if no)");
            bool isHostelite = bool.Parse(Console.ReadLine());            

            Console.WriteLine("Is student Taking Scholarship or not!(Enter \"true\" if yes \"false\" if no)");
            bool istakingscholarship = bool.Parse(Console.ReadLine());
            Student s = new Student(name, rollNumber, cgpa, mMarks, fMarks, eMarks,homeTown, isHostelite,istakingscholarship);
            return s;
        }

        static void addtolist(List<Student> sl,Student s)
        {
            sl.Add(s);
        }
    }
}







