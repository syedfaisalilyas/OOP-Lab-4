﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task3.BL
{
    class Customer
    {
        public string Name;
        public string Adress;
        public int Contact;
        public List<Product> products = new List<Product>();
        public List<Product> getAllProducs()
        {
            return products;
        }
        public void addproduct(Product p)
        {
            products.Add(p);
        }
    }
}
