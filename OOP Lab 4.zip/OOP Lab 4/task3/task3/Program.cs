﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using uams.BL;

namespace uams
{
    class Program
    {
        public static int idx = 0;
        static void Main(string[] args)
        {

            List<Student> StudentList = new List<Student>();
            List<DegreeProgram> ProgramList = new List<DegreeProgram>();
            List<DegreeProgram> userListofprograms = new List<DegreeProgram>();
            string degree = "";
            string code = "";
            string name = "";
            int option = 0;
            while (true)
            {

                option = Menu();
                if (option == 1)
                {
                    Student s = AddStudentUI(ProgramList);
                    AddStudent(StudentList, s);
                }
                else if (option == 2)
                {
                    DegreeProgram p = AddProgramUI();
                    AggDegree(ProgramList, p);
                }
                else if (option == 3)
                {
                    GenerateMerit(StudentList);


                }
                else if (option == 4)
                {
                    ViewRegisteredStudents(StudentList);
                }
                else if (option == 5)
                {
                    Console.WriteLine("Enter Degree Name:");
                    degree = Console.ReadLine();
                    specificdegreeprogram(degree, StudentList);
                }
                else if (option == 6)
                {
                    Console.WriteLine("Enter Student Name:");
                    name = Console.ReadLine();
                    Console.WriteLine("Enter Subject Code:");
                    code = Console.ReadLine();
                    RegSubject(name, code, StudentList);
                }
                else if (option == 7)
                {
                    CalculateFee(StudentList);
                }
                else if (option == 8)
                {
                    break;
                }
                Console.ReadLine();
                clearScreen();
            }
        }
        static int Menu()
        {
            int op;
            Console.WriteLine("*******************************************");
            Console.WriteLine("********************UAMS*******************");
            Console.WriteLine("*******************************************");
            Console.WriteLine("1:Add Student");
            Console.WriteLine("2:Add Degree Program");
            Console.WriteLine("3:Generate Merit");
            Console.WriteLine("4:View Registered Students");
            Console.WriteLine("5:View Students of a Specific Program");
            Console.WriteLine("6:Register Subjects For a Specific Student");
            Console.WriteLine("7:Calculate Fees for all Registered Students");
            Console.WriteLine("8:Exit");
            Console.WriteLine("Enter your option");
            op = int.Parse(Console.ReadLine());
            return op;

        }
        static Student AddStudentUI(List<DegreeProgram> ProgramList)
        {
            int no_of_pref;
            Student s = new Student();
            Console.WriteLine("Enter Student Name:");
            s.StudentName = Console.ReadLine();
            Console.WriteLine("Enter Student Age:");
            s.StudentAge = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Student FSC Marks:");
            s.FscMarks = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Student Ecat Marks:");
            s.EcatMarks = int.Parse(Console.ReadLine());
            Console.WriteLine("Availaible Degree program");
            for (int i = 0; i < ProgramList.Count; i++)
            {
                Console.WriteLine(ProgramList[i].ProgramTitle + "\t");
            }
            Console.WriteLine("Enter how many preferences to enter:");
            no_of_pref = int.Parse(Console.ReadLine());
            for (int i = 0; i < no_of_pref; i++)
            {
                string pref = takingpref(ProgramList);
                s.Preferences.Add(ProgramList[idx]);
            }
            return s;
        }
        static void AddStudent(List<Student> StudentList, Student S)
        {
            StudentList.Add(S);
        }
        static string takingpref(List<DegreeProgram> ProgramList)
        {
            string pref = "";
            bool flag = false;
            while (flag != true)
            {
                pref = Console.ReadLine();
                for (int i = 0; i < ProgramList.Count; i++)
                {
                    if (pref == ProgramList[i].ProgramTitle)
                    {
                        flag = true;
                        idx = i;
                        break;
                    }
                }
                if (flag == false)
                {
                    Console.WriteLine("You entered wrong input..enter again...");
                }
            }
            return (pref);
        }
        static DegreeProgram AddProgramUI()
        {
            List<Subject> ListofSub = new List<Subject>();
            float merit;
            int no_of_subjects;
            string ProgramTitle, DegreeDuration;
            int AvailableSeats;
            Console.WriteLine("Enter Degree title:");
            ProgramTitle = Console.ReadLine();
            Console.WriteLine("Enter Degree duration:");
            DegreeDuration = Console.ReadLine();
            Console.WriteLine("Enter no of Available Seats:");
            AvailableSeats = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter merit of this degree program:");
            merit = float.Parse(Console.ReadLine()); ;
            Console.WriteLine("Enter how many subjects to enter:");
            no_of_subjects = int.Parse(Console.ReadLine());
            for (int i = 0; i < no_of_subjects; i++)
            {
                Subject s = getsubject();
                ListofSub.Add(s);
            }
            DegreeProgram S = new DegreeProgram(ProgramTitle, DegreeDuration, AvailableSeats, merit, ListofSub);
            return S;
        }
        static Subject getsubject()
        {
            Subject s = new Subject();

            Console.WriteLine("Enter Subject code:");
            s.SubjectCode = Console.ReadLine();
            Console.WriteLine("Enter Subject type:");
            s.SubjectType = Console.ReadLine();
            Console.WriteLine("Enter Credit Hours:");
            s.CreditHours = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Subject fees:");
            s.SubjectFee = int.Parse(Console.ReadLine());
            return s;
        }
        static void AggDegree(List<DegreeProgram> Listofprograms, DegreeProgram P)
        {
            Listofprograms.Add(P);
        }

        static void GenerateMerit(List<Student> StudentList)
        {
            for (int i = 0; i < StudentList.Count; i++)
            {
                StudentList[i].GenerateMerit();
            }
        }
        static void ViewRegisteredStudents(List<Student> StudentList)
        {
            int count = 0;
            Console.WriteLine("Name\t\tFsc\t\tEcat\t\tAge");
            for (int i = 0; i < StudentList.Count; i++)
            {
                if (StudentList[i].registered == true)
                {
                    Console.WriteLine(StudentList[i].StudentName + "\t\t" + StudentList[i].FscMarks + "\t\t" + StudentList[i].EcatMarks + "\t\t" + StudentList[i].StudentAge);
                }
                count++;
            }
            if (count == 0)
            {
                Console.WriteLine("No students are registered yet");
            }
        }
        static void specificdegreeprogram(string degree, List<Student> StudentList)
        {
            Console.WriteLine("Name\t\tFsc\t\tEcat\t\tAge");
            for (int i = 0; i < StudentList.Count; i++)
            {
                if (degree == StudentList[i].gotadmissionin)
                {
                    Console.WriteLine(StudentList[i].StudentName + "\t\t" + StudentList[i].FscMarks + "\t\t" + StudentList[i].EcatMarks + "\t\t" + StudentList[i].StudentAge);
                }
            }
        }
        static void RegSubject(string name, string code, List<Student> StudentList)
        {
            for (int i = 0; i < StudentList.Count; i++)
            {
                if (name == StudentList[i].StudentName)
                {
                    StudentList[i].registersubject(code);
                }
            }
        }
        static void CalculateFee(List<Student> StudentList)
        {
            float fee;
            for (int i = 0; i < StudentList.Count; i++)
            {
                fee = StudentList[i].calculatefee();
                Console.WriteLine("{0}'s fees is {1}", StudentList[i].StudentName, fee);
            }
        }
        static void clearScreen()
        {
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
            Console.Clear();
        }
    }
}
